// Limitador de intentos en memoria (sin dependencias): frena fuerza bruta en login/registro.
export function limitador({ ventanaMs = 15 * 60 * 1000, max = 10, mensaje = 'Demasiados intentos. Probá de nuevo en unos minutos.' } = {}) {
  const golpes = new Map(); // ip -> [timestamps]
  return (req, res, next) => {
    const ahora = Date.now();
    const ip = req.ip || req.socket?.remoteAddress || 'x';
    const recientes = (golpes.get(ip) || []).filter((t) => ahora - t < ventanaMs);
    if (recientes.length >= max) {
      res.set('Retry-After', String(Math.ceil(ventanaMs / 1000)));
      return res.status(429).json({ error: mensaje });
    }
    recientes.push(ahora);
    golpes.set(ip, recientes);
    if (golpes.size > 5000) for (const [k, v] of golpes) if (!v.some((t) => ahora - t < ventanaMs)) golpes.delete(k);
    next();
  };
}
